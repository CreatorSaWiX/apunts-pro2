#include "game.hh"
#include "assert.hh"

#include <iostream>

using namespace pro2;
using namespace std;

Game::Game(int width, int height)
    : mario_({width / 2, 150}),
      platforms_{
          Platform(100, 300, 200, 211),
          Platform(0, 200, 250, 261),
          Platform(250, 400, 150, 161),
      },
      puntuacio_(0),
      finished_(false) {
    assert(width > 0 && height > 0, "L'amplada i l'alcada del joc han de ser positives.");

    for (int i = 1; i < 1000000; i++) {
        platforms_.push_back(Platform(250 + i * 200, 400 + i * 200, 150, 161));
        coins_.push_back(Coin({250 + i * 200, 120}));
    }

    for(Platform& p : platforms_) platforms_finder_.add(&p);
    for(Coin& c : coins_) coins_finder_.add(&c);
}

void Game::process_keys(pro2::Window& window) {
    if (window.is_key_down(Keys::Escape)) {
        finished_ = true;
        return;
    }
}

void Game::update_objects(pro2::Window& window) {
    vector<Platform> nearby_platforms;
    for(const Platform *p : platforms_finder_.query(window.camera_rect())){
        nearby_platforms.push_back(*p);
    }

    mario_.update(window, nearby_platforms);

    for(const Coin *c_ : coins_finder_.query(window.camera_rect())){
        if(!c_->collect() && overlaps(c_->get_rect(), mario_.get_rect())){
            int idx = c_ - &coins_[0];
            coins_[idx].collected();
            
            puntuacio_++;
            cout << "puntuacio: " <<  puntuacio_ << endl;
        }
    }
}

void Game::update_camera(pro2::Window& window) {
    const Pt pos = mario_.pos();
    const Pt cam = window.camera_center();

    const int left = cam.x - window.width() / 4;
    const int right = cam.x + window.width() / 4;
    const int top = cam.y - window.height() / 4;
    const int bottom = cam.y + window.height() / 4;

    int dx = 0, dy = 0;
    if (pos.x > right) {
        dx = pos.x - right;
    } else if (pos.x < left) {
        dx = pos.x - left;
    }
    if (pos.y < top) {
        dy = pos.y - top;
    } else if (pos.y > bottom) {
        dy = pos.y - bottom;
    }

    window.move_camera({dx, dy});
}

void Game::update(pro2::Window& window) {
    process_keys(window);
    update_objects(window);
    update_camera(window);
}

void Game::paint(pro2::Window& window) {
    window.clear(sky_blue);

    for(const Platform *p : platforms_finder_.query(window.camera_rect())){
        p->paint(window);
    }

    mario_.paint(window);

    for(const Coin *c_ : coins_finder_.query(window.camera_rect())){
        if(!c_->collect()){
            c_->paint(window);
        }
    }
}