#ifndef FINDER_HH
#define FINDER_HH

#include <map>
#include <set>
#include <vector>

template <typename T>
class Finder {
    const int divisio = 256;
    std::map<pro2::Pt, std::set<const T*>> M;
    std::map<const T*, std::vector<pro2::Pt>> M_pos;

public:
    Finder() {}

    void add(const T *t){
        pro2::Rect r = t->get_rect();
        int min_x = r.left/divisio;
        int max_x = r.right/divisio;
        int min_y = r.top/divisio;
        int max_y = r.bottom/divisio;

        std::vector<pro2::Pt> celles;
        for(int x = min_x; x <= max_x; ++x){
            for(int y = min_y; y <= max_y; ++y){
                pro2::Pt p = {x, y};
                M[p].insert(t);
                celles.push_back(p);
            }
        }

        M_pos[t] = celles;
    }

    void update(const T *t){
        remove(t);
        add(t);
    }

    void remove(const T *t){
        auto it = M_pos.find(t);
        if(it != M_pos.end()){
            for(const pro2::Pt &p : it->second){
                M[p].erase(t);
                if(M[p].empty()) M.erase(p);
            }

            M_pos.erase(it);
        }
    }

    /**
     * @brief Retorna el conjunt d'objectes amb rectangles total o
     *        parcialment dins de `rect`.
     *
     * Si el nombre de rectangles del contenidor és `n`, el cost
     * de l'algorisme ha de ser O(log n).
     *
     * @param rect El rectangle de cerca
     *
     * @returns Un conjunt de punters a objectes que tenen un rectangle
     *          parcial o totalment dins de `rect`
     */
    std::set<const T *> query(pro2::Rect rect) const{
        std::set<const T*> result;
        int min_x = rect.left/divisio;
        int max_x = rect.right/divisio;
        int min_y = rect.top/divisio;
        int max_y = rect.bottom/divisio;

        for(int x = min_x; x <= max_x; ++x){
            for(int y = min_y; y <= max_y; ++y){
                auto it = M.find({x,y});
                if(it != M.end()){
                    for(const T *t : it->second){
                        if(pro2::overlaps(t->get_rect(), rect)){
                            result.insert(t);
                        }
                    }
                }
            }
        }

        return result;
    }
};

#endif