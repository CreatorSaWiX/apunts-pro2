#include "window.hh"
#include <vector>
#include "coin.hh"
#include "utils.hh"
#include <iostream>

using namespace pro2;
using namespace std;

const int _ = -1;
const int y = yellow;
const int g = grey;

const vector<vector<int>> Coin::coin_sprite_ = {
    {_, _, g, g, g, g, _, _},
    {_, g, y, y, y, y, g, _},
    {g, y, y, y, y, y, y, g},
    {g, y, y, y, y, y, y, g},
    {g, y, y, y, y, y, y, g},
    {g, y, y, y, y, y, y, g},
    {_, g, y, y, y, y, g, _},
    {_, _, g, g, g, g, _, _},
};

void Coin::paint(pro2::Window& window) const {
    if(!collected_){
        int animate_y = initial_y_+ 5 * sin(window.frame_count() * 0.1);
        const Pt top_left = {pos_.x - 4, animate_y - 4};
        paint_sprite(window, top_left, coin_sprite_, false);
    }
}

