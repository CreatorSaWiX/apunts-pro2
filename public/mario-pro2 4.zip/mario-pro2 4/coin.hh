#ifndef COIN_HH
#define COIN_HH

#include "geometry.hh"
#include <vector>
#include "window.hh"

class Coin{
private:
    pro2::Pt pos_;
    int initial_y_;
    bool collected_ = false;

    static const std::vector<std::vector<int>> coin_sprite_;
public:
    Coin(pro2::Pt pos) : pos_(pos), initial_y_(pos.y){}

    void paint(pro2::Window& window) const;

    //setter
    void collected(){
        collected_ = true;
    }

    //getter
    bool collect() const{
        return collected_;
    }

    pro2::Rect get_rect() const {
        return {pos_.x - 4, pos_.y - 4, pos_.x + 4, pos_.y +4};
    }
};

#endif