#ifndef FINDER_HH
#define FINDER_HH

#include <map>
#include <set>
#include "geometry.hh"

template <typename T>
class Finder {
    int max_width = 0;
    int max_height = 0;
    std::map<pro2::Pt, std::set<const T*>> M;
public:
    Finder() {}

    void add(const T *t){
        pro2::Rect r = t->get_rect();
        pro2::Pt p = {r.left, r.top};
        M[p].insert(t);

        int width = r.right - r.left;
        if(width > max_width) max_width = width;
        
        int height = r.bottom - r.top;
        if(height > max_height) max_height = height;
    }

    void update(const T *t){
        auto it = M.begin();
        bool trobat = false;

        while(!trobat && it != M.end()){
            if(it->second.find(t) != it->second.end()){
                it->second.erase(t);
                if(it->second.empty()){
                    M.erase(it->first);
                }
                trobat = true;
            } else {
                ++it;
            }
        }

        add();
    }

    void remove(const T *t){
        pro2::Rect r = t->get_rect();
        pro2::Pt p = {r.left, r.top};

        if(M.find(p) != M.end()){
            M[p].erase(t);
            if(M[p].empty()){
                M.erase(p);
            }
        }
    }

    /**
     * @brief Retorna el conjunt d'objectes amb rectangles total o
     *        parcialment dins de `rect`.
     *
     * Si el nombre de rectangles del contenidor és `n`, el cost
     * de l'algorisme ha de ser O(log n).
     *
     * @param rect El rectangle de cerca
     *
     * @returns Un conjunt de punters a objectes que tenen un rectangle
     *          parcial o totalment dins de `rect`
     */
    std::set<const T *> query(pro2::Rect rect) const{
        std::set<const T *> result;
        auto it = M.lower_bound({rect.left - max_width, rect.top - max_height});

        while(it != M.end() && it->first.x <= rect.right){
            if(it->first.y < rect.top - max_height){
                it = M.lower_bound({it->first.x, rect.top - max_height});
            } else if(it->first.y > rect.bottom){
                it = M.lower_bound({it->first.x + 1, rect.top - max_height});
            } else {
                for(const T *t: it->second){
                    if(pro2::overlaps(t->get_rect(), rect)){
                        result.insert(t);
                    }
                }
                ++it;
            }
        }

        return result;
    }
};

#endif